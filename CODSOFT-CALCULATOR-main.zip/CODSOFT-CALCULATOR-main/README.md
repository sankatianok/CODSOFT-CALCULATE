# 🧮 Calculator  

A simple and interactive **Calculator Application** built with HTML, CSS, and JavaScript.  
It performs basic arithmetic operations with a clean and responsive UI.  

---

## ✨ Features  
- ✅ Basic arithmetic: **Addition, Subtraction, Multiplication, Division**  
- ✅ Clear button (AC) and delete (⌫) functionality  
- ✅ Responsive design (works on mobile & desktop)  
- ✅ Supports multiple digits and decimal calculations  
- ✅ Keyboard input support (optional, if added)  

---

## 🚀 Technologies Used  
- **HTML5** – structure  
- **CSS3** – styling & layout  
- **JavaScript (ES6)** – functionality
